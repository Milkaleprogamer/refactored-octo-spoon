BDLib was planned as a library for my future datapacks, but I'm not sure that I want to release it as a separate project.
If I'm in the mood, I'll finish it and upload it on Modrinth
¯\_(ツ)_/¯